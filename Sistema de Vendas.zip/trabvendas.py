categorias = ["Informática", "Móveis"]
margemLucro = [1.50,1.60]

produtosInformatica = []
produtosMoveis = []

precosInformatica = []
precosMoveis = []

carrinho = []
precoCarrinho= []

resp ='s'
while resp == 's':
    categoria = input("Qual a categoria? \n 1- Informática \n 2 - Móveis \n Opção:")
    
    if categoria == '1':
        produtosInformatica.append(input("Digite o nome do produto da Categoria Informática: \n"))
        precosInformatica.append(float(input("Digite o valor do produto de Informática:")))
    elif categoria == '2':
        produtosMoveis.append(input("Digite o nome do produto da Categoria Móveis: \n"))
        precosMoveis.append(float(input("Digite o valor do produto de Móveis:")))
          
    resp = str(input("Deseja continuar? [s/n] \n"))
    if resp == 'n':
        print("Cadastro finalizado com sucesso!\n-------------------------------------------------\nRecalculando preços com a margem de lucro...")

i=0
for item in precosInformatica:
    precosInformatica[i] = item * margemLucro[0]
    print("[Produtos da Categoria Informática]",produtosInformatica[i],' - Valor recalculado: ', precosInformatica)
    i=+1


i=0
for item in precosMoveis:
    precosMoveis[i] = item * margemLucro[1]
    print("[Produtos da Categoria Móveis]",produtosMoveis[i], ' - Valor recalculado: ', precosMoveis)
    i=+1
    
print ("-------------------------------------------------\nIniciando vendas... ") 



controle = True
while controle:
    valor = float(input('Qual é o valor máximo de pesquisa em reais? '))
    categoria = input('Qual é a categoria da pesquisa? \n 1- Informática \n 2 - Móveis \n Opção: ')

    i=0
    if categoria == '1':
        for item in precosInformatica:
            if precosInformatica[i]<= valor:
                print('[',i,']', produtosInformatica[i], ' - Valor: ', precosInformatica[i])
                
                
            else:
                print('Produtos deste valor são inexistentes!')

            i=i+1
        c= int(input('Digite o código do pruduto para adicionar no carrinho: '))
        precoCarrinho.append(precosInformatica[c])
        carrinho.append(produtosInformatica[c])
        
    elif categoria == '2':
        i=0    
        for item in precosMoveis:
            if precosMoveis[i] <= valor:
                print('[',i,']', produtosMoveis[i], ' - Valor: ', precosMoveis[i])

            else:
                print('Produtos deste valor são inexistentes!')

            i=i+1
        c= int(input('Digite o código do produto para adicionar no carrinho: '))
        precoCarrinho.append(precosMoveis[c])
        carrinho.append(produtosMoveis[c])

    controle= str(input('Deseja continuar a compra? [s/n]\n'))
    
    if controle == 'n':
        break
print ("-------------------------------------------------\n", 'Listando produtos no carrinho:')
        
      
i= 0
for item in carrinho:
    print ([i], carrinho[i], ' - Valor: ', precoCarrinho [i])
    i=i+1
    
x=0
while x != 'fim' or x != 'FIM' or x != 'Fim':
    x = input('Para remover um produto digite o código, caso contrário digite FIM:\n ')
    if x == 'fim' or x == 'FIM' or x == 'Fim':
        break

    else:
        x = int (x)
        precoCarrinho.pop (x)
        print('Produto', carrinho.pop (x), 'removido')

soma = 0
for valor in precoCarrinho:
    soma = soma + valor

print('Total da compra:', soma)
